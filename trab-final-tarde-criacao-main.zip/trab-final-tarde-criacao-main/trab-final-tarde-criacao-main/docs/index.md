# SIMULADOR DE APLICAÇÕES FINANCEIRAS E CRÉDITO


O Projeto de software feito no editor de texto Visual Studio Code. 

Para este foi construído uma página inicial estática utilizando os conhecimentos de boas práticas de engenharia de software e os códicos HTML, CSS e JavaScript. 

O layout da página inicial possui em sua interface alguns componentes como: menu de navegação lateral, ícones do menu com animação, seção de conteúdo destaque para os produtos e otimização para mobile. 

Além disso, na parte superior da página tem barra de pesquisa ao lado a imagem do logotipo. 

Abaixo junto ao conteúdo tem dois botões de simuladores e produtos que direcionam para a parte seguinte. Os tipos de produtos para simulação são: Poupança Digital, Fundos Imobiliários e Crédito. 

A seguir tem o catálogo desses produtos com botões de direcionamento para o quadro dos respectivos simuladores. 

Assim o usuário é direcionado a escolher na barra de opções o produto, colocar os  valores, período mensal e a taxa de rendimento. 

Após isto clica em fazer o orçamento das aplicações financeiras e crédito.

Porfim, o usuário tem a opção de começar a investir para gerar o resultado da simulação.














