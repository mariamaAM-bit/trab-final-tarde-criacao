  Tema do Trabalho: simulador de parcelamento de créditos/ aplicaçôes financeiras.
  - o site não vai conter login.
  - o público alvo que procurar e analisar os rendimentos em aplicações financeiras.
  - o site será com intuito de simular vários tipos de aplicações financeiras.
  - nesse simulador o usuário pode comparar diferentes valores e prazos de pagamento para decidir qual é a melhor oferta para o seu bolso.
  - o site vai inserir apenas um menu iniciar com os tipos de aplicações.
  - entrando no menu o usuário escolhe o tipo de aplicação financeira e clicando nela abre outra página com o simulador desta aplicação.
