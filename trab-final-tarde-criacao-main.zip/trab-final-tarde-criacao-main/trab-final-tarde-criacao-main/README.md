# Simulador de aplicações financeiras e crédito
Este repositório apresenta o projeto de software de Simulação de aplicações financeiras e crédito, seguindo todas as boas práticas da Engenharia de Software.


## Sumário

* Pré-requisitos(#pré-requisitos)
* Instalação(#instalação)
* Instruções de uso(#instruções-de-uso)
* Contato(#contato)
* Bibliografia(#bibliografia)

## Pré-requisitos

## Instalação


## Instruções de Uso


## Contato



## Bibliografia



## Checklist

Protótipo no Figma

Diagrama de classe

Diagrama de caso de uso

Documentação no GitHub Pages com MKDocs 

Testes unitários com QUnit

linter com ESLint

Produto final (software)

GitHub Actions para rodar tudo automaticamente

documentação e deploy do site

testes

linter

## Configuração

Confira as instruções de configuração em 

## Execução

Confira o site rodando em 
